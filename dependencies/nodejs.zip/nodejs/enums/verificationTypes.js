const VerificationTypes = {
    waiting: "W",
    passive: "P",
    verified: "V"
};
module.exports = VerificationTypes;