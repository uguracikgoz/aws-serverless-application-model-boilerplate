const MessageSenders = {
    microsoftTeams : "microsoftTeams"
};
module.exports = MessageSenders;