const ErrorCodes = {
    tokenExpired:""
};
module.exports = ErrorCodes;