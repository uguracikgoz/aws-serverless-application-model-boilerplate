'use strict';  
const AlertMessageFactory  = require('./alertMessageFactory.js');
module.exports = AlertMessageFactory;