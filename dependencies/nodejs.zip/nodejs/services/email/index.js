'use strict';  
const Email  = require('./email.js');
module.exports = Email;