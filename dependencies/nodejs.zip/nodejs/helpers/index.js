'use strict';  
const Response  = require('./response.js');
module.exports = {
    Response:Response
}